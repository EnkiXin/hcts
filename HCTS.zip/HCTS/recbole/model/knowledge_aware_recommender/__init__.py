from recbole.model.knowledge_aware_recommender.cfkg import CFKG
from recbole.model.knowledge_aware_recommender.cke import CKE
from recbole.model.knowledge_aware_recommender.kgat import KGAT
from recbole.model.knowledge_aware_recommender.kgcn import KGCN
from recbole.model.knowledge_aware_recommender.kgnnls import KGNNLS
from recbole.model.knowledge_aware_recommender.ktup import KTUP
from recbole.model.knowledge_aware_recommender.mkr import MKR
from recbole.model.knowledge_aware_recommender.ripplenet import RippleNet
