from recbole_cdr.trainer.trainer import *

__all__ = ['CrossDomainTrainer']
