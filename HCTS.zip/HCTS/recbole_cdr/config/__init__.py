from recbole_cdr.config.configurator import CDRConfig
